package com.rochatransportes.service;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

import org.springframework.stereotype.Component;

import com.rochatransportes.model.Nota;

/**
 * PILHA (LIFO - Last In, First Out) de notas fiscais excluídas.
 *
 * Funciona como o "Ctrl+Z": a última nota excluída é a primeira a ser
 * restaurada. Cada exclusão faz um push (empilhar) e cada "desfazer"
 * faz um pop (desempilhar).
 *
 * Implementada com ArrayDeque, que a própria documentação do Java recomenda
 * no lugar da classe antiga java.util.Stack (mais rápida e sem sincronização
 * desnecessária). Usamos apenas as operações de pilha: push, pop e peek.
 *
 * A pilha tem um limite (CAPACIDADE_MAXIMA). Quando está cheia, a exclusão
 * mais antiga (a do fundo da pilha) é descartada para dar espaço à nova.
 *
 * Observação: a pilha fica na memória do servidor. Se o backend for
 * reiniciado, o histórico de exclusões é perdido.
 */
@Component
public class PilhaNotasExcluidas {

    public static final int CAPACIDADE_MAXIMA = 10;

    private final Deque<Nota> pilha = new ArrayDeque<>();

    /** Empilha uma nota excluída no topo da pilha. */
    public synchronized void push(Nota nota) {
        if (pilha.size() >= CAPACIDADE_MAXIMA) {
            pilha.removeLast(); // descarta a exclusão mais antiga (fundo da pilha)
        }
        pilha.push(nota); // push = adiciona no topo
    }

    /** Remove e devolve a nota do topo (a última excluída), ou null se vazia. */
    public synchronized Nota pop() {
        return pilha.isEmpty() ? null : pilha.pop();
    }

    /** Devolve a nota do topo sem remover, ou null se vazia. */
    public synchronized Nota peek() {
        return pilha.peek();
    }

    public synchronized boolean isEmpty() {
        return pilha.isEmpty();
    }

    public synchronized int size() {
        return pilha.size();
    }

    /** Cópia do conteúdo, do topo (mais recente) para o fundo (mais antiga). */
    public synchronized List<Nota> listar() {
        return new ArrayList<>(pilha);
    }
}
