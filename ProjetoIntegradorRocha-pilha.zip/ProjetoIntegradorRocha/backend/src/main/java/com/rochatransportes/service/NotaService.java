package com.rochatransportes.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rochatransportes.model.Nota;
import com.rochatransportes.model.Ajudante;
import com.rochatransportes.repository.AjudanteRepository;
import com.rochatransportes.repository.NotaRepository;

@Service
@Transactional
public class NotaService {

    @Autowired
    private NotaRepository notaRepository;

    @Autowired
    private AjudanteRepository ajudanteRepository;

    // Pilha com as notas excluídas, usada para "desfazer exclusão"
    @Autowired
    private PilhaNotasExcluidas pilhaExcluidas;

    public List<Nota> findAll() {
        return notaRepository.findAll(Sort.by(Sort.Direction.DESC, "id"));
    }

    public Page<Nota> findAllPaginated(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "id"));
        return notaRepository.findAll(pageable);
    }

    public Optional<Nota> findById(Long id) {
        Long notaId = Objects.requireNonNull(id, "ID da nota não pode ser nulo");
        return notaRepository.findById(notaId);
    }

    public Nota save(Nota nota) {
        // Garantir que os campos legados sejam preenchidos com os novos campos
        if (nota.getNomeColetador() != null && !nota.getNomeColetador().isEmpty()) {
            nota.setColetadoPor(nota.getNomeColetador());
        }
        if (nota.getNomeEntregador() != null && !nota.getNomeEntregador().isEmpty()) {
            nota.setEntreguePor(nota.getNomeEntregador());
        }
        if (nota.getNomeCliente() != null && !nota.getNomeCliente().isBlank()) {
            nota.setCliente(nota.getCliente() == null || nota.getCliente().isBlank() ? nota.getNomeCliente() : nota.getCliente());
        }
        prepararAjudantes(nota);
        return notaRepository.save(nota);
    }

    public Nota update(Long id, Nota nota) {
        Long notaId = Objects.requireNonNull(id, "ID da nota não pode ser nulo");
        if (!notaRepository.existsById(notaId)) {
            throw new RuntimeException("Nota não encontrada com ID: " + id);
        }
        nota.setId(notaId);
        // Garantir que os campos legados sejam preenchidos
        if (nota.getNomeColetador() != null && !nota.getNomeColetador().isEmpty()) {
            nota.setColetadoPor(nota.getNomeColetador());
        }
        if (nota.getNomeEntregador() != null && !nota.getNomeEntregador().isEmpty()) {
            nota.setEntreguePor(nota.getNomeEntregador());
        }
        if (nota.getNomeCliente() != null && !nota.getNomeCliente().isBlank()) {
            nota.setCliente(nota.getCliente() == null || nota.getCliente().isBlank() ? nota.getNomeCliente() : nota.getCliente());
        }
        prepararAjudantes(nota);
        return notaRepository.save(nota);
    }

    public void delete(Long id) {
        Long notaId = Objects.requireNonNull(id, "ID da nota não pode ser nulo");
        Nota nota = notaRepository.findById(notaId)
                .orElseThrow(() -> new RuntimeException("Nota não encontrada com ID: " + id));
        // Guarda uma cópia da nota no topo da pilha ANTES de apagar do banco
        pilhaExcluidas.push(copiarNota(nota));
        notaRepository.deleteById(notaId);
    }

    /**
     * Desfaz a última exclusão: tira a nota do topo da pilha (pop)
     * e grava de novo no banco. Retorna null se a pilha estiver vazia.
     */
    public Nota desfazerUltimaExclusao() {
        Nota nota = pilhaExcluidas.pop();
        if (nota == null) {
            return null;
        }
        nota.setId(null); // o banco gera um novo ID ao restaurar
        prepararAjudantes(nota); // ignora ajudantes que tenham sido excluídos nesse meio-tempo
        return notaRepository.save(nota);
    }

    /** Notas excluídas que ainda podem ser restauradas (da mais recente para a mais antiga). */
    public List<Nota> listarExcluidas() {
        return pilhaExcluidas.listar();
    }

    private Nota copiarNota(Nota o) {
        Nota c = new Nota();
        c.setId(o.getId()); // ID antigo, só para exibição na lixeira
        c.setNumeroNota(o.getNumeroNota());
        c.setQuantidade(o.getQuantidade());
        c.setRazaoSocialDestino(o.getRazaoSocialDestino());
        c.setCidadeDestino(o.getCidadeDestino());
        c.setCnpjDestino(o.getCnpjDestino());
        c.setColetadoPor(o.getColetadoPor());
        c.setEntreguePor(o.getEntreguePor());
        c.setDataColeta(o.getDataColeta());
        c.setDataEntrega(o.getDataEntrega());
        c.setCliente(o.getCliente());
        c.setIdCliente(o.getIdCliente());
        c.setNomeCliente(o.getNomeCliente());
        c.setIdVeiculo(o.getIdVeiculo());
        c.setNomeVeiculo(o.getNomeVeiculo());
        c.setPlacaVeiculo(o.getPlacaVeiculo());
        c.setAjudantes(new ArrayList<>(o.getAjudantes()));
        c.setTipoColetador(o.getTipoColetador());
        c.setIdColetador(o.getIdColetador());
        c.setNomeColetador(o.getNomeColetador());
        c.setTipoEntregador(o.getTipoEntregador());
        c.setIdEntregador(o.getIdEntregador());
        c.setNomeEntregador(o.getNomeEntregador());
        return c;
    }

    public List<Nota> findByCliente(String cliente) {
        return notaRepository.findByClienteContainingIgnoreCase(cliente);
    }

    public List<Nota> findByNumeroNota(Integer numeroNota) {
        return notaRepository.findByNumeroNota(numeroNota);
    }

    public List<Nota> findNotasPendentes() {
        return notaRepository.findByDataEntregaIsNullOrderByDataColetaAsc();
    }

    private void prepararAjudantes(Nota nota) {
        if (nota.getAjudantes() == null || nota.getAjudantes().isEmpty()) {
            nota.setAjudantes(new ArrayList<>());
            return;
        }

        List<Long> ids = nota.getAjudantes().stream()
                .map(Ajudante::getId)
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());

        if (ids.isEmpty()) {
            nota.setAjudantes(new ArrayList<>());
            return;
        }

        List<Ajudante> ajudantes = ajudanteRepository.findAllById(ids);
        nota.setAjudantes(ids.stream()
                .map(id -> ajudantes.stream().filter(ajudante -> id.equals(ajudante.getId())).findFirst().orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList()));
    }
}
