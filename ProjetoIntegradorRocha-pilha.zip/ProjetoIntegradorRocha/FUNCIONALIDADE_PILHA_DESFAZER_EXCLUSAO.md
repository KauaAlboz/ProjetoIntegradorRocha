# Funcionalidade: Desfazer exclusão de Nota Fiscal (Pilha)

## O que foi feito
Na tela **Notas Fiscais** foi criado o botão **"Desfazer exclusão"**. Quando uma nota é excluída, uma cópia dela vai para uma **pilha**. Ao clicar no botão, a **última nota excluída** volta para o sistema. Clicando de novo, volta a penúltima, e assim por diante (como o Ctrl+Z). O número ao lado do botão mostra quantas exclusões podem ser desfeitas.

## Arquivos alterados
| Arquivo | Alteração |
|---|---|
| `backend/.../service/PilhaNotasExcluidas.java` | **Novo.** A estrutura de dados Pilha (push, pop, peek, size), com limite de 10 itens. |
| `backend/.../service/NotaService.java` | `delete()` agora empilha uma cópia da nota antes de apagar. Novos métodos `desfazerUltimaExclusao()` (pop + salvar de novo) e `listarExcluidas()`. |
| `backend/.../controller/NotaController.java` | Novos endpoints `GET /api/notas/excluidas` e `POST /api/notas/desfazer-exclusao`. |
| `frontend/.../services/nota.service.ts` | Métodos `listarExcluidas()` e `desfazerExclusao()`. |
| `frontend/.../nota-list/nota-list.component.ts` | Botão "Desfazer exclusão" com contador. |

## Por que Pilha?
- Desfazer segue a regra **LIFO** (o último a entrar é o primeiro a sair): o que o usuário quer recuperar normalmente é o que ele acabou de apagar.
- As operações usadas (`push` ao excluir e `pop` ao desfazer) custam **O(1)**, ou seja, são instantâneas, não importa o tamanho da pilha.
- **Por que não Fila?** A Fila é FIFO: o desfazer devolveria a nota excluída há mais tempo, e não a mais recente.
- **Por que não Mapa?** O Mapa serve para achar algo por uma chave (ex.: pelo ID), mas não guarda a ordem das exclusões, que é o que importa aqui.
- **Por que não Array/Árvore?** Daria para usar, mas seria preciso controlar índices ou ordenação na mão. A pilha já faz exatamente o que a funcionalidade precisa.
- Usei `ArrayDeque` como pilha porque a documentação do Java recomenda ela no lugar da classe antiga `Stack`.

## Consequências para a aplicação
- **Positivas:** o usuário pode corrigir uma exclusão feita por engano sem cadastrar a nota de novo.
- **A pilha fica na memória do servidor:** se o backend for reiniciado, o histórico de exclusões é perdido.
- **Limite de 10:** quando a pilha enche, a exclusão mais antiga é descartada.
- **Novo ID:** a nota restaurada recebe um ID novo (o banco gera). O número da nota e os outros dados continuam iguais. Uma rota que guardava o ID antigo da nota não é atualizada automaticamente.
- **Ajudantes:** se algum ajudante da nota foi excluído nesse meio-tempo, ele é ignorado na restauração.
- A pilha é **compartilhada** entre todos os usuários logados (é um único objeto no servidor), e os métodos são `synchronized` para evitar conflito em acessos ao mesmo tempo.
